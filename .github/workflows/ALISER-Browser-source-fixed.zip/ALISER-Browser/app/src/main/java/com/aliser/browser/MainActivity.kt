package com.aliser.browser

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Tab
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import org.mozilla.geckoview.ContentBlocking
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoRuntimeSettings
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoView

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AliserBrowser() }
    }
}

private data class BrowserTab(
    val id: Int,
    val session: GeckoSession,
    val view: GeckoView,
    var url: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AliserBrowser() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("aliser", 0) }
    val history = remember { mutableStateListOf<String>().apply {
        addAll(prefs.getStringSet("history", emptySet())?.toList() ?: emptyList())
    } }
    val bookmarks = remember { mutableStateListOf<String>().apply {
        addAll(prefs.getStringSet("bookmarks", emptySet())?.toList() ?: emptyList())
    } }

    val runtime = remember {
        val cb = ContentBlocking.Settings.Builder()
            .antiTracking(ContentBlocking.AntiTracking.DEFAULT or ContentBlocking.AntiTracking.STP)
            .build()
        GeckoRuntime.create(context, GeckoRuntimeSettings.Builder()
            .contentBlocking(cb)
            .build())
    }

    fun makeTab(id: Int): BrowserTab =
        BrowserTab(id, GeckoSession(), GeckoView(context), "https://duckduckgo.com")

    val tabs = remember { mutableStateListOf(makeTab(1)) }
    var activeId by remember { mutableIntStateOf(1) }
    val active = tabs.firstOrNull { it.id == activeId } ?: tabs.first()
    var address by remember { mutableStateOf(active.url) }
    var showTabs by remember { mutableStateOf(false) }
    var showLibrary by remember { mutableStateOf(false) }
    var libraryTitle by remember { mutableStateOf("Bookmarks") }

    LaunchedEffect(active.id) {
        if (!active.session.isOpen) active.session.open(runtime)
        active.view.setSession(active.session)
        address = active.url
        active.session.loadUri(active.url)
    }

    fun go(raw: String) {
        val q = raw.trim()
        if (q.isEmpty()) return
        val target = when {
            q.startsWith("https://") || q.startsWith("http://") -> q
            q.contains(" ") || !q.contains(".") -> "https://duckduckgo.com/?q=${Uri.encode(q)}"
            else -> "https://$q"
        }
        address = target
        active.url = target
        active.session.loadUri(target)
        if (history.firstOrNull() != target) {
            history.add(0, target)
            while (history.size > 100) history.removeAt(history.lastIndex)
            prefs.edit().putStringSet("history", history.toSet()).apply()
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Color(0xFF9BE15D),
        onPrimary = Color(0xFF10200A),
        background = Color(0xFF0B1010),
        surface = Color(0xFF141C1B),
        surfaceVariant = Color(0xFF202B29),
        onSurface = Color(0xFFE7F0ED)
    )) {
        Scaffold(
            containerColor = Color(0xFF0B1010),
            topBar = {
                Column(Modifier.fillMaxWidth().background(Color(0xFF0B1010)).padding(horizontal = 12.dp, vertical = 8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(34.dp).background(Color(0xFF9BE15D), CircleShape), contentAlignment = Alignment.Center) {
                            Text("A", color = Color(0xFF10200A), style = MaterialTheme.typography.titleLarge)
                        }
                        Spacer(Modifier.width(9.dp))
                        Column(Modifier.weight(1f)) {
                            Text("ALISER", color = Color.White, style = MaterialTheme.typography.titleMedium)
                            Text("BROWSER", color = Color(0xFF9BE15D), style = MaterialTheme.typography.labelSmall)
                        }
                        IconButton(onClick = { showTabs = true }) {
                            Icon(Icons.Default.Tab, contentDescription = "Tabs", tint = Color.White)
                        }
                        Text("${tabs.size}", color = Color.White)
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(
                        Modifier.fillMaxWidth().background(Color(0xFF202B29), RoundedCornerShape(18.dp)).padding(start = 12.dp, end = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Lock, contentDescription = "Secure", tint = Color(0xFF9BE15D), modifier = Modifier.size(18.dp))
                        TextField(
                            value = address,
                            onValueChange = { address = it },
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            placeholder = { Text("Search or enter address") },
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent
                            ),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                            keyboardActions = KeyboardActions(onGo = { go(address) })
                        )
                        TextButton(onClick = { go(address) }) { Text("GO", color = Color(0xFF9BE15D)) }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Enhanced Tracking Protection", color = Color(0xFF9BE15D), style = MaterialTheme.typography.labelSmall)
                        Spacer(Modifier.weight(1f))
                        TextButton(onClick = {
                            if (address.isNotBlank() && !bookmarks.contains(address)) {
                                bookmarks.add(address)
                                prefs.edit().putStringSet("bookmarks", bookmarks.toSet()).apply()
                            }
                        }) {
                            Icon(Icons.Default.Bookmark, contentDescription = null, modifier = Modifier.size(16.dp))
                            Text("Save")
                        }
                        IconButton(onClick = { active.session.reload() }) {
                            Icon(Icons.Default.Refresh, contentDescription = "Reload", tint = Color.White)
                        }
                    }
                }
            },
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF141C1B)) {
                    NavigationBarItem(selected = false, onClick = { go("https://duckduckgo.com") },
                        icon = { Icon(Icons.Default.Home, contentDescription = "Home") }, label = { Text("Home") })
                    NavigationBarItem(selected = false, onClick = { libraryTitle = "Bookmarks"; showLibrary = true },
                        icon = { Icon(Icons.Default.Bookmark, contentDescription = "Bookmarks") }, label = { Text("Saved") })
                    NavigationBarItem(selected = false, onClick = { libraryTitle = "History"; showLibrary = true },
                        icon = { Icon(Icons.Default.History, contentDescription = "History") }, label = { Text("History") })
                }
            }
        ) { padding ->
            AndroidView(factory = { active.view }, modifier = Modifier.fillMaxSize().padding(padding))
        }
    }

    if (showTabs) {
        AlertDialog(
            onDismissRequest = { showTabs = false },
            title = { Text("Tabs") },
            text = {
                Column {
                    tabs.toList().forEach { tab ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(tab.url, modifier = Modifier.weight(1f), maxLines = 1)
                            TextButton(onClick = { activeId = tab.id; address = tab.url; showTabs = false }) { Text("Open") }
                            TextButton(onClick = {
                                if (tabs.size > 1) {
                                    tab.session.close()
                                    tabs.remove(tab)
                                    if (activeId == tab.id) activeId = tabs.first().id
                                }
                            }) { Text("×") }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val nextId = (tabs.maxOfOrNull { it.id } ?: 0) + 1
                    tabs.add(makeTab(nextId))
                    activeId = nextId
                    showTabs = false
                }) { Text("New tab") }
            }
        )
    }

    if (showLibrary) {
        val entries = if (libraryTitle == "Bookmarks") bookmarks.toList() else history.toList()
        AlertDialog(
            onDismissRequest = { showLibrary = false },
            title = { Text(libraryTitle) },
            text = {
                if (entries.isEmpty()) Text("Nothing here yet.")
                else LazyColumn(Modifier.heightIn(max = 360.dp)) {
                    items(entries) { item ->
                        TextButton(onClick = { showLibrary = false; go(item) }) { Text(item, maxLines = 2) }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showLibrary = false }) { Text("Close") } }
        )
    }
}
